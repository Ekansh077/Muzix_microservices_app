package com.cg.MuzixApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.MuzixApp.exception.DuplicateTrackException;
import com.cg.MuzixApp.exception.TrackNotFoundException;
import com.cg.MuzixApp.exception.UseridNotAvailableException;
import com.cg.MuzixApp.model.Favourites;
import com.cg.MuzixApp.model.Register;
import com.cg.MuzixApp.model.Track;
import com.cg.MuzixApp.service.MuzixAppService;

@RestController
public class MuzixAppController {
	
	@Autowired
	public MuzixAppService service;
	
	@PostMapping("/tracks")
	public Track addTrack(@RequestBody Track track) throws DuplicateTrackException {
		return service.saveTrack(track);
	}
	
	@GetMapping("/tracks")
	public List<Track> getAllTracks(){
		return service.getAllTracks();
	}
	
	@DeleteMapping("/tracks/id/{id}")
	public ResponseEntity<Boolean> deleteTrackById(@PathVariable("id") int id) throws TrackNotFoundException{
		boolean isDeleted = service.deleteTrack(id);
		return new ResponseEntity<>(isDeleted,HttpStatus.OK);
	}
	
	@GetMapping("/tracks/id/{id}")
	public Track getTrackById(@PathVariable("id") int id) throws TrackNotFoundException{
		return service.getTrackById(id);
	}
	
	@PutMapping("/tracks/update")
	public ResponseEntity<Track> updateTrack(@RequestBody Track track) throws TrackNotFoundException{
		Track updatedTrack = service.updateTrack(track);
		return ResponseEntity.ok(updatedTrack);
	}
	
	@PostMapping("/tracks/fav/id/{id}")
	public Favourites setFavouriteById(@PathVariable("id") int id) throws TrackNotFoundException{
		return service.addFavouriteWithId(id);
	}
	
	@GetMapping("/tracks/fav")
	public List<Favourites> getAllFavourites(){
		return service.getAllFavourites();
	}
	
	@PostMapping("/tracks/register")
	public Register addUserDetails(@RequestBody Register register) throws UseridNotAvailableException{
		return service.saveUserDetails(register);
	}
	
	@GetMapping("/tracks/name/{trackName}")
	public Track searchByTrackName(@PathVariable String trackName) throws TrackNotFoundException {
		return service.getTrackByName(trackName);
	}
	
	@GetMapping("/tracks/recommendations")
	public List<Track> getRecommendations(){
		return service.getRecommendations();
	}
}
