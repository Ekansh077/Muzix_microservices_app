package com.cg.MuzixApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.MuzixApp.model.Track;

@Repository
public interface MuzixAppRepo extends JpaRepository<Track, Integer>{
	@Query("from Track where trackName=:trackName")
	public Track findByTrackName(String trackName);
}
