package com.cg.MuzixApp.exception;

public class TrackNotFoundException extends Exception{
	public TrackNotFoundException(String message){
		super(message);
	}
}
