package com.cg.MuzixApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.MuzixApp.model.Register;

public interface RegisterRepo extends JpaRepository<Register, String>{

}
