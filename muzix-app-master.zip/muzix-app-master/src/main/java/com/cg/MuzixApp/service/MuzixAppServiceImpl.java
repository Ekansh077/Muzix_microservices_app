package com.cg.MuzixApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.MuzixApp.exception.DuplicateTrackException;
import com.cg.MuzixApp.exception.TrackNotFoundException;
import com.cg.MuzixApp.exception.UseridNotAvailableException;
import com.cg.MuzixApp.model.Favourites;
import com.cg.MuzixApp.model.Register;
import com.cg.MuzixApp.model.Track;
import com.cg.MuzixApp.repository.FavouritesRepo;
import com.cg.MuzixApp.repository.MuzixAppRepo;
import com.cg.MuzixApp.repository.RegisterRepo;

@Service
public class MuzixAppServiceImpl implements MuzixAppService{

	@Autowired
	MuzixAppRepo repo;
	
	@Autowired
	FavouritesRepo favRepo;
	
	@Autowired
	RegisterRepo regRepo;
	
	@Override
	public Track saveTrack(Track track) throws DuplicateTrackException{
		if(repo.existsById(track.getId())) {
			throw new DuplicateTrackException("Track with Code - "+track.getId()+" already present..");
		}
		return repo.save(track);
	}

	@Override
	public boolean deleteTrack(int id) throws TrackNotFoundException{
		if(!repo.existsById(id)) {
			throw new TrackNotFoundException("Track with Code - "+id+" not found..");
		}
		repo.deleteById(id);
		return !repo.existsById(id);
	}

	@Override
	public List<Track> getAllTracks() {
		return repo.findAll();
	}

	@Override
	public Track getTrackById(int id) throws TrackNotFoundException{
		if(!repo.existsById(id)) {
			throw new TrackNotFoundException("Track with Code - "+id+" not found..");
		}
		return repo.findById(id).get();
	}

	@Override
	public Track getTrackByName(String trackName) {
		return repo.findByTrackName(trackName);
	}

	@Override
	public Track updateTrack(Track track) throws TrackNotFoundException{
		if(!repo.existsById(track.getId())) {
			throw new TrackNotFoundException("Track with Code - "+track.getId()+" not found..");
		}
		return repo.save(track);
	}

	@Override
	public Favourites addFavouriteWithId(int id) throws TrackNotFoundException{
		if(!repo.existsById(id)) {
			throw new TrackNotFoundException("Track with Code - "+id+" not found..");
		}
		Track track = repo.findById(id).get();
		Favourites fav = new Favourites(track.getId(),track.getTrackName(),track.getArtist());
		return favRepo.save(fav);
	}

	@Override
	public List<Favourites> getAllFavourites() {
		return favRepo.findAll();
	}

	@Override
	public Register saveUserDetails(Register register) throws UseridNotAvailableException{
		if(regRepo.existsById(register.getUserId())) {
			throw new UseridNotAvailableException("Track with Code - "+register.getUserId()+" already present..");
		}
		return regRepo.save(register);
	}

	@Override
	public List<Track> getRecommendations() {
		return repo.findAll();
	}
}


