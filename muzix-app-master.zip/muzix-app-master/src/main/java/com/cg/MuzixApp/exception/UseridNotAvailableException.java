package com.cg.MuzixApp.exception;

public class UseridNotAvailableException extends Exception{
	
	public UseridNotAvailableException(String message){
		super(message);
	}

}
