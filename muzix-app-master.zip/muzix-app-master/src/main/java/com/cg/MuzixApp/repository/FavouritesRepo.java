package com.cg.MuzixApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.MuzixApp.model.Favourites;

public interface FavouritesRepo extends JpaRepository<Favourites, Integer>{

}
