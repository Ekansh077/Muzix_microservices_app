package com.cg.MuzixApp.exception;

public class DuplicateTrackException extends Exception{
	public DuplicateTrackException(String message){
		super(message);
	}
}
