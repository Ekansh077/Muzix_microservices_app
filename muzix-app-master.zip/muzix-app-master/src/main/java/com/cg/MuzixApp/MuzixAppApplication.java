package com.cg.MuzixApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MuzixAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MuzixAppApplication.class, args);
	}

}
