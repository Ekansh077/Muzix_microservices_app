package com.cg.MuzixApp.service;

import java.util.List;

import com.cg.MuzixApp.exception.DuplicateTrackException;
import com.cg.MuzixApp.exception.TrackNotFoundException;
import com.cg.MuzixApp.exception.UseridNotAvailableException;
import com.cg.MuzixApp.model.Favourites;
import com.cg.MuzixApp.model.Register;
import com.cg.MuzixApp.model.Track;

public interface MuzixAppService {

	   public Track saveTrack(Track track) throws DuplicateTrackException;

	   public boolean deleteTrack(int id) throws TrackNotFoundException;

	   public List<Track> getAllTracks();

	   public Track getTrackById(int id) throws TrackNotFoundException;

	   public Track getTrackByName(String trackName) throws TrackNotFoundException;

	   public Track updateTrack(Track track) throws TrackNotFoundException;
	   
	   public Favourites addFavouriteWithId(int id) throws TrackNotFoundException;
	   
	   public List<Favourites> getAllFavourites();
	   
	   public Register saveUserDetails(Register register) throws UseridNotAvailableException;
	   
	   public List<Track> getRecommendations();
	   
}
