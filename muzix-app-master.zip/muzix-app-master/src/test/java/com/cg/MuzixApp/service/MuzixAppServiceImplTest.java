package com.cg.MuzixApp.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cg.MuzixApp.exception.DuplicateTrackException;
import com.cg.MuzixApp.exception.TrackNotFoundException;
import com.cg.MuzixApp.exception.UseridNotAvailableException;
import com.cg.MuzixApp.model.Favourites;
import com.cg.MuzixApp.model.Register;
import com.cg.MuzixApp.model.Track;
import com.cg.MuzixApp.repository.FavouritesRepo;
import com.cg.MuzixApp.repository.MuzixAppRepo;
import com.cg.MuzixApp.repository.RegisterRepo;

@ExtendWith(SpringExtension.class)
class MuzixAppServiceImplTest {

	Track track = new Track(101,"No Lie","Dua Lipa");
	
	Register user = new Register("karthik@gmail.com","Hello@123");
	
	List<Track> list = null;
	
	List<Favourites> favList=null;
	
	@InjectMocks
	MuzixAppServiceImpl service;
	
	@Mock
	private MuzixAppRepo repo;
	
	@Mock
	private FavouritesRepo favRepo;
	
	@Mock
	private RegisterRepo regRepo;
	
	@Test
	public void testSaveTrack() throws DuplicateTrackException {
		when(repo.save(track)).thenReturn(track);
		assertEquals(track, service.saveTrack(track));
	}
	
	@Test
	public void testGetTrackById() throws TrackNotFoundException {
		when(repo.existsById(101)).thenReturn(true);
		when(repo.findById(101)).thenReturn(Optional.of(track));
		
		int trackId=101;
		Track track1 = service.getTrackById(trackId);
		assertEquals(track1,track);
	}

	@Test
	public void testUpdateTrack() {
		when(repo.save(track)).thenReturn(track);
		
		Track trackNew = new Track(101,"No Lie","Dua Lipa");
		assertEquals(track, repo.save(trackNew));
	}
	
	@Test
	public void testDeleteTrack() throws TrackNotFoundException {
		repo.save(track);
		when(repo.existsById(101)).thenReturn(true);
		when(repo.findById(101)).thenReturn(Optional.of(track));
		
		int trackId=101;
		repo.deleteById(trackId);
		when(!repo.existsById(trackId)).thenReturn(true);
	}
	
	@Test
	public void testGetAllTracks() {
		repo.save(track);
		when(repo.findAll()).thenReturn(list);
		
		List<Track> trackList = service.getAllTracks();
		assertEquals(list, trackList);
	}
	
	@Test
	public void testAddFavouriteWithId() throws TrackNotFoundException {
		Favourites fav = new Favourites(101,"No Lie","Dua Lipa");
		repo.save(track);
		when(repo.existsById(101)).thenReturn(true);
		when(repo.findById(101)).thenReturn(Optional.of(track));
		when(favRepo.save(fav)).thenReturn(fav);
		assertEquals(fav, service.addFavouriteWithId(101));
	}
	
	@Test
	public void testGetAllFavourites() {
		Favourites fav = new Favourites(101,"No Lie","Dua Lipa");
		favRepo.save(fav);
		when(favRepo.findAll()).thenReturn(favList);
		
		List<Favourites> favList1 = service.getAllFavourites();
		assertEquals(favList, favList1);
	}
	
	@Test
	public void testSaveUserDetails() throws UseridNotAvailableException {
		when(regRepo.save(user)).thenReturn(user);
		assertEquals(user, service.saveUserDetails(user));
	}
	
	@Test
	public void testGetRecommendations() {
		
		when(repo.findAll()).thenReturn(list);
		
		List<Track> trackList = service.getRecommendations();
		assertEquals(list, trackList);
	}
	
	@Test
	public void testGetTrackByName() {
		when(repo.findByTrackName("No Lie")).thenReturn(track);
		
		Track track1 = service.getTrackByName("No Lie");
		assertEquals(track, track1);
	}
}
