package com.cg.MuzixApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuzixAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
